import { GoogleGenAI } from "@google/genai";
import { SparePart } from "../types";

// Initialize safely - if key is missing, we don't crash the app, but calls will fail gracefully
const apiKey = process.env.API_KEY || "Missing_Key";
const ai = new GoogleGenAI({ apiKey });

export const analyzeInventory = async (query: string, dataSample: SparePart[]): Promise<string> => {
  if (apiKey === "Missing_Key") {
    return "API Key is missing. Please add GEMINI_API_KEY to your Vercel Environment Variables.";
  }

  // We limit the sample size to avoid token limits, prioritizing high value items
  const topItems = dataSample
    .sort((a, b) => b.totalValue - a.totalValue)
    .slice(0, 50)
    .map(p => `- [${p.factoryId}] Code: ${p.materialNumber}, Part: ${p.partNumber}, Desc: ${p.description}, Qty: ${p.onHand}, Value: Rs. ${p.totalValue}, Machine: ${p.machine}`);

  const prompt = `
    You are an Inventory Optimization Expert for Tile Factories.
    User Query: "${query}"

    Here is a data sample of the top 50 highest-value non-moving spare parts (all considered dead stock) across our factories:
    ${topItems.join('\n')}

    Please analyze this data and answer the user's query. 
    If they ask for recommendations, suggest parts that could be shared between factories or consolidated.
    All currency values are in Sri Lankan Rupees (Rs).
    Be concise, professional, and data-driven.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-1.5-flash',
      contents: prompt,
    });
    return response.text || "No analysis could be generated.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Sorry, I encountered an error while analyzing the inventory data.";
  }
};