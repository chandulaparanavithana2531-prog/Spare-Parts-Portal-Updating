import { collection, doc, writeBatch, getDocs, setDoc, getDoc, query, where, Timestamp, deleteDoc } from 'firebase/firestore';
import { db } from './firebase';
import { SparePart, User, Order, OrderStatus } from '../types';
import { logAction } from './audit';

// --- Inventory Operations ---

export const saveInventory = async (parts: SparePart[], performerUsername: string) => {
  console.log(`[DB] Received payload: ${parts.length} items to save.`);
  
  // Batch writes in Firestore are limited to 500 operations.
  const BATCH_SIZE = 450;
  const batches = [];

  // 1. Prepare all batches
  for (let i = 0; i < parts.length; i += BATCH_SIZE) {
    const chunk = parts.slice(i, i + BATCH_SIZE);
    const batch = writeBatch(db);

    chunk.forEach(part => {
      const ref = doc(db, 'inventory', part.id);
      batch.set(ref, part);
    });
    batches.push(batch);
  }

  console.log(`[DB] Prepared ${batches.length} batches.`);

  // 2. Commit in concurrent chunks
  const CONCURRENCY_LIMIT = 5;
  let successCount = 0;
  
  for (let i = 0; i < batches.length; i += CONCURRENCY_LIMIT) {
    const currentBatches = batches.slice(i, i + CONCURRENCY_LIMIT);
    try {
      await Promise.all(currentBatches.map(b => b.commit()));
      successCount += currentBatches.reduce((acc, b, idx) => {
        const batchIdx = i + idx;
        const chunkSize = batches[batchIdx] === batches[batches.length - 1] 
          ? parts.length % BATCH_SIZE || BATCH_SIZE 
          : BATCH_SIZE;
        return acc + chunkSize;
      }, 0);
      console.log(`[DB] Progress: ${successCount} / ${parts.length} items committed.`);
    } catch (error) {
      console.error("[DB] Batch commit failed.", error);
      throw error;
    }
  }

  console.log(`[DB] Successfully saved ${successCount} total items to database.`);

  // Log the upload action
  if (parts.length > 0) {
    try {
      await logAction(
        performerUsername,
        'UPLOAD',
        'inventory',
        parts[0].factoryId, // Using factory ID as entity ID for bulk upload
        `Uploaded ${parts.length} items for ${parts[0].factoryId}`
      );
    } catch (auditError) {
      // Don't fail the whole upload if just the logging fails, 
      // but warn about it in the console.
      console.warn("[DB] Audit logging failed after successful inventory update:", auditError);
    }
  }
};

export const getInventory = async (): Promise<SparePart[]> => {
  const querySnapshot = await getDocs(collection(db, 'inventory'));
  const parts: SparePart[] = [];
  querySnapshot.forEach((doc) => {
    parts.push(doc.data() as SparePart);
  });
  return parts;
};

export const updateSparePart = async (part: SparePart, performerUsername: string) => {
  const ref = doc(db, 'inventory', part.id);
  await setDoc(ref, part);
  await logAction(
    performerUsername,
    'UPDATE',
    'inventory',
    part.id,
    `Updated item: ${part.description}`
  );
};

// --- Order Operations ---

export const createOrder = async (
  items: import('../types').CartItem[],
  username: string
): Promise<void> => {
  // Group items by Factory ID
  const itemsByFactory: Record<string, import('../types').CartItem[]> = {};

  items.forEach(item => {
    if (!itemsByFactory[item.factoryId]) {
      itemsByFactory[item.factoryId] = [];
    }
    itemsByFactory[item.factoryId].push(item);
  });

  const batch = writeBatch(db);

  // Create separate order for each factory group
  Object.entries(itemsByFactory).forEach(([factoryId, factoryItems]) => {
    const orderId = `ord-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
    const totalValue = factoryItems.reduce((sum, item) => sum + (item.unitCost * item.orderQty), 0);

    const order: Order = {
      id: orderId,
      items: factoryItems.map(item => ({
        sparePartId: item.id,
        sparePartDescription: item.description,
        partNumber: item.partNumber || '',  // Save Snapshot
        machine: item.machine || '',        // Save Snapshot
        fromFactory: item.factoryId,
        quantity: item.orderQty,
        unitCost: item.unitCost,
        totalValue: item.unitCost * item.orderQty,
        status: 'pending' // Initialize item status
      })),
      totalValue,
      requestedBy: username,
      status: 'pending',
      createdAt: Date.now()
    };

    const ref = doc(db, 'orders', orderId);
    batch.set(ref, order);

    // Log the order creation (we'll log each split order)
    logAction(
      username,
      'CREATE',
      'order',
      orderId,
      `Created order for factory ${factoryId} with ${factoryItems.length} items. Total: ${totalValue}`
    );
  });

  await batch.commit();
};

export const getOrders = async (user?: User): Promise<Order[]> => {
  try {
    const querySnapshot = await getDocs(collection(db, 'orders'));
    const orders: Order[] = [];

    querySnapshot.forEach((doc) => {
      const data = doc.data() as Order;
      // Safety check
      if (!data.items || data.items.length === 0) return;

      // Filter Logic:
      // 1. Admin sees everything.
      // 2. User sees orders they REQUESTED.
      // 3. User sees orders targeted TO THEIR FACTORY.

      if (user) {
        if (user.role === 'admin') {
          orders.push(data);
        } else {
          // Check if I am the requester
          const isRequester = data.requestedBy === user.username;

          // Check if I am the target factory (Owner of these parts)
          // Since we split orders by factory, we just need to check the first item's factory
          const isTargetFactory = user.factoryAffiliation && data.items[0].fromFactory === user.factoryAffiliation;

          if (isRequester || isTargetFactory) {
            orders.push(data);
          }
        }
      } else {
        orders.push(data);
      }
    });

    return orders;
  } catch (e) {
    console.error("Error fetching orders:", e);
    return [];
  }
};

export const processOrderItem = async (orderId: string, itemPartId: string, status: OrderStatus, performerUsername: string) => {
  const orderRef = doc(db, 'orders', orderId);
  const orderSnap = await getDoc(orderRef);

  if (!orderSnap.exists()) {
    throw new Error("Order not found");
  }

  const order = orderSnap.data() as Order;
  const itemIndex = order.items.findIndex(i => i.sparePartId === itemPartId);

  if (itemIndex === -1) throw new Error("Item not found in order");

  const item = order.items[itemIndex];

  // LOGIC:
  // 1. 'approved' -> Just marks the item as approved (Reserved). NO Stock Deduction yet.
  // 2. 'delivered' -> Marks as delivered AND Deducts Stock.
  // 3. 'rejected' -> Just marks as rejected.

  if (status === 'delivered' && item.status !== 'delivered') {
    // FINAL STOCK DEDUCTION
    const batch = writeBatch(db);

    const partRef = doc(db, 'inventory', item.sparePartId);
    const partSnap = await getDoc(partRef);

    if (!partSnap.exists()) {
      throw new Error(`Part ${item.sparePartDescription} not found`);
    }

    const part = partSnap.data() as SparePart;

    // Double check stock (even though we might have reserved it visually, physical stock must be there)
    if (part.onHand < item.quantity) {
      throw new Error(`Insufficient physical stock for ${item.sparePartDescription} to deliver.`);
    }

    const newOnHand = part.onHand - item.quantity;
    const newTotalValue = newOnHand * part.unitCost;

    batch.update(partRef, { onHand: newOnHand, totalValue: newTotalValue });

    // Update item status
    order.items[itemIndex].status = 'delivered';

    // Update Order Status
    // If all items are 'delivered' or 'rejected', order is complete.
    // For now, let's just update the main status to 'delivered' if all items are delivered.
    const allDelivered = order.items.every(i => i.status === 'delivered' || i.status === 'rejected');
    const mainStatus = allDelivered ? 'delivered' : 'approved'; // Keep as approved/partial until fully delivered

    batch.update(orderRef, { items: order.items, status: mainStatus });
    await batch.commit();

    await logAction(
      performerUsername,
      'ORDER_PROCESS',
      'order',
      orderId,
      `Delivered item: ${item.sparePartDescription} (Qty: ${item.quantity})`
    );

  } else if (status === 'approved' && item.status === 'pending') {
    // RESERVATION ONLY (No physical deduction yet)
    // We just update the status.
    order.items[itemIndex].status = 'approved';

    const batch = writeBatch(db);

    // Check if all are processed to move main status out of pending
    const allProcessed = order.items.every(i => i.status !== 'pending');
    const mainStatus = allProcessed ? 'approved' : 'pending';

    batch.update(orderRef, { items: order.items, status: mainStatus, approvedAt: Date.now() });
    await batch.commit();

    await logAction(
      performerUsername,
      'ORDER_PROCESS',
      'order',
      orderId,
      `Approved item: ${item.sparePartDescription} (Qty: ${item.quantity})`
    );

  } else {
    // Rejecting or resetting
    order.items[itemIndex].status = status;

    const allProcessed = order.items.every(i => i.status !== 'pending');
    // If we reject, we might still be pending if other items are pending
    const mainStatus = allProcessed ? (order.items.some(i => i.status === 'approved' || i.status === 'delivered') ? 'approved' : 'rejected') : 'pending';

    await setDoc(orderRef, { ...order, items: order.items, status: mainStatus });

    await logAction(
      performerUsername,
      'ORDER_PROCESS',
      'order',
      orderId,
      `${status === 'rejected' ? 'Rejected' : 'Reset'} item: ${item.sparePartDescription}`
    );
  }
};

// --- Auth ---

/**
 * Simple SHA-256 hash using Web Crypto API.
 * In production, use a library like bcrypt with proper salting on the server.
 */
const hashPassword = async (password: string): Promise<string> => {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex;
};

export const registerUser = async (user: User, password: string): Promise<void> => {
  // Check if username already exists
  const usersRef = collection(db, 'users');
  const q = query(usersRef, where('username', '==', user.username));
  const querySnapshot = await getDocs(q);

  if (!querySnapshot.empty) {
    throw new Error('Username already taken');
  }

  const hashedPassword = await hashPassword(password);

  // Save user to Firestore 'users' collection
  await setDoc(doc(db, 'users', user.username), {
    ...user,
    approved: false, // Default to unapproved
    password: hashedPassword
  });
};

export const loginUser = async (username: string, password: string): Promise<User | null> => {
  // 1. Hardcoded Admin (Legacy/Fallback)
  if (username === 'admin' && password === 'vone') {
    return { username: 'admin', role: 'admin', approved: true };
  }

  // 2. Dynamic Users from Firestore
  try {
    const userDocRef = doc(db, 'users', username);
    const userDoc = await getDoc(userDocRef);

    if (userDoc.exists()) {
      const userData = userDoc.data();
      const inputHash = await hashPassword(password);

      // Check Password: Try Hash match first, then fallback to Plaintext (for migration)
      const isHashMatch = userData.password === inputHash;
      const isPlainMatch = userData.password === password;

      if (isHashMatch || isPlainMatch) {

        // Check Approval
        if (!userData.approved) {
          throw new Error("Account pending approval");
        }

        // Return user info (excluding password)
        return {
          username: userData.username,
          role: userData.role,
          factoryAffiliation: userData.factoryAffiliation,
          approved: userData.approved
        };
      }
    }
  } catch (e) {
    console.error("Login error:", e);
    throw e; // Re-throw to handle specific errors like "Account pending approval"
  }

  return null;
};

// --- Admin User Management ---

export const getPendingUsers = async (): Promise<User[]> => {
  const usersRef = collection(db, 'users');
  const q = query(usersRef, where('approved', '==', false));
  const querySnapshot = await getDocs(q);

  const users: User[] = [];
  querySnapshot.forEach((doc) => {
    // Exclude password
    const data = doc.data();
    users.push({
      username: data.username,
      role: data.role,
      factoryAffiliation: data.factoryAffiliation,
      approved: data.approved
    });
  });
  return users;
};

export const getAllUsers = async (): Promise<User[]> => {
  const usersRef = collection(db, 'users');
  const querySnapshot = await getDocs(usersRef);

  const users: User[] = [];
  querySnapshot.forEach((doc) => {
    const data = doc.data();
    users.push({
      username: data.username,
      role: data.role,
      factoryAffiliation: data.factoryAffiliation,
      approved: data.approved
    });
  });
  return users;
};

export const approveUser = async (username: string, performerUsername: string, factoryAffiliation?: string) => {
  const userRef = doc(db, 'users', username);
  const updateData: any = { approved: true };
  if (factoryAffiliation) {
    updateData.factoryAffiliation = factoryAffiliation;
  }
  await setDoc(userRef, updateData, { merge: true });
  await logAction(
    performerUsername,
    'USER_APPROVE',
    'user',
    username,
    `Approved user registration: ${username}${factoryAffiliation ? ` with factory ${factoryAffiliation}` : ''}`
  );
};

export const deleteUser = async (username: string, performerUsername: string) => {
  await deleteDoc(doc(db, 'users', username));
  await logAction(
    performerUsername,
    'DELETE',
    'user',
    username,
    `Deleted user: ${username}`
  );
};

// --- Helper for Robust Deletions ---

/**
 * Standardizes bulk deletion to avoid Firestore's 500-operation batch limit.
 */
const deleteInBatches = async (querySnapshot: any) => {
  const BATCH_SIZE = 450;
  const docs = querySnapshot.docs;
  
  for (let i = 0; i < docs.length; i += BATCH_SIZE) {
    const batch = writeBatch(db);
    const chunk = docs.slice(i, i + BATCH_SIZE);
    chunk.forEach((d: any) => batch.delete(d.ref));
    await batch.commit();
    console.log(`[DB] Deleted batch of ${chunk.length} documents.`);
  }
};

export const clearDatabase = async (performerUsername: string) => {
  // 1. Clear Inventory
  console.log("[DB] Clearing Inventory...");
  const inventorySnapshot = await getDocs(collection(db, 'inventory'));
  await deleteInBatches(inventorySnapshot);

  // 2. Clear Orders
  console.log("[DB] Clearing Orders...");
  const ordersSnapshot = await getDocs(collection(db, 'orders'));
  await deleteInBatches(ordersSnapshot);

  await logAction(
    performerUsername,
    'CLEAR_DATABASE',
    'inventory',
    'all',
    `Cleared all data (${inventorySnapshot.size} parts, ${ordersSnapshot.size} orders)`
  );
};

export const clearOrders = async (performerUsername: string) => {
  const ordersSnapshot = await getDocs(collection(db, 'orders'));
  if (ordersSnapshot.empty) return;

  await deleteInBatches(ordersSnapshot);

  await logAction(
    performerUsername,
    'CLEAR_DATABASE',
    'order',
    'all',
    `Cleared ${ordersSnapshot.size} order history records`
  );
};

export const clearAuditLogs = async (performerUsername: string) => {
  const snapshot = await getDocs(collection(db, 'audit_logs'));
  if (snapshot.empty) return;

  await deleteInBatches(snapshot);

  await logAction(
    performerUsername,
    'CLEAR_DATABASE',
    'audit_logs',
    'all',
    `Cleared all security audit logs (${snapshot.size} records)`
  );
};

export const deleteFactoryData = async (factoryId: string, performerUsername: string) => {
  // Query all inventory items for this factory
  const inventoryRef = collection(db, 'inventory');
  const q = query(inventoryRef, where('factoryId', '==', factoryId));
  const querySnapshot = await getDocs(q);

  if (querySnapshot.empty) return;

  await deleteInBatches(querySnapshot);

  await logAction(
    performerUsername,
    'DELETE',
    'inventory',
    factoryId,
    `Deleted ${querySnapshot.size} inventory items for factory: ${factoryId}`
  );
};
