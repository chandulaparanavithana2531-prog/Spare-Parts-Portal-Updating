import * as XLSX from 'xlsx';
import { SparePart } from '../types';

// Helper to normalize keys slightly to handle case variations
const normalizeKey = (key: string): string => key.trim().toLowerCase();

// Helper to extract Drive ID and create direct link
const getDirectDriveLink = (url: string): string | null => {
  if (!url) return null;
  let id = '';
  const parts = url.split('/');

  // Case 1: /file/d/ID/view
  const dIndex = parts.indexOf('d');
  if (dIndex !== -1 && parts.length > dIndex + 1) {
    id = parts[dIndex + 1];
  } else {
    // Case 2: id=ID param
    const match = url.match(/[?&]id=([^&]+)/);
    if (match) {
      id = match[1];
    }
  }

  if (!id) return null;

  // Use Thumbnail API for reliable embedding
  return `https://drive.google.com/thumbnail?id=${id}&sz=w1000`;
};

export interface ExcelParseResult {
  parts: SparePart[];
  metadata: {
    totalRows: number;
    validItems: number;
    filteredItems: number;
    duplicateIds: number;
    totalCollisions: number;
    factoryId: string;
    fileName: string;
  };
}

export const parseExcelFile = async (file: File, factoryId: string): Promise<ExcelParseResult> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];

        const rawArray = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];

        let headerRowIndex = 0;
        const keyColumns = ['material', 'part', 'description', 'stock', 'qty', 'value', 'price', 'cost', 'on hand', 'item code', 'criticality', 'priority'];

        for (let i = 0; i < Math.min(20, rawArray.length); i++) {
          const rowStr = rawArray[i].map(cell => String(cell).toLowerCase()).join(' ');
          let matchCount = 0;
          keyColumns.forEach(key => {
            if (rowStr.includes(key)) matchCount++;
          });

          if (matchCount >= 2) {
            headerRowIndex = i;
            break;
          }
        }

        const rawRows = XLSX.utils.sheet_to_json(worksheet, { range: headerRowIndex }) as any[];
        
        const idCounts: Record<string, number> = {};
        let filteredCount = 0;

        const parts: SparePart[] = rawRows.map((row) => {
          const getVal = (keys: string[]) => {
            for (const k of keys) {
              if (row[k] !== undefined) return row[k];
              const foundKey = Object.keys(row).find(rk => rk.toLowerCase() === k.trim().toLowerCase());
              if (foundKey) return row[foundKey];
            }
            return null;
          };

          const parseNum = (val: any) => {
            if (typeof val === 'number') return val;
            if (typeof val === 'string') {
              const clean = val.replace(/[^0-9.-]/g, '');
              return parseFloat(clean) || 0;
            }
            return 0;
          };

          let materialNumber = getVal(['Material Number', 'Material No', 'Item Code', 'Code', 'Material Code', 'Mat No', 'Item No', 'Material', 'Stock Code']);
          let partNumber = getVal(['Part Number', 'Part No', 'PartNo', 'Ref No', 'Part Code', 'Manufacturer Part No']);

          if (!materialNumber && partNumber) materialNumber = partNumber;
          if (!partNumber && materialNumber) partNumber = materialNumber;

          if (!materialNumber) {
            filteredCount++;
            return null;
          }

          const description = getVal(['Description', 'Item Description', 'Material Description', 'Item Name', 'Desc']) || 'No Description';
          const onHand = parseNum(getVal(['On hand', 'On Hand Qty', 'Stock', 'Current Stock', 'Quantity', 'Qty', 'Closing Stock', 'Physical Stock', 'Unrestricted', 'Total Stock', 'Stk Qty']));
          let unitCost = parseNum(getVal(['Unit Cost', 'Avg Cost', 'Unit Value', 'Rate', 'Price', 'Standard Cost', 'Cost', 'W.Avg.Cost', 'Unit Price', 'Moving Price', 'MAP', 'Unit Rate']));
          let totalValue = parseNum(getVal(['Total Value', 'Value', 'Total Amount', 'Amount', 'Stock Value', 'Inventory Value', 'Total', 'Total Cost', 'Gross Value', 'Net Value']));

          if (totalValue > 0 && unitCost === 0 && onHand > 0) {
            unitCost = totalValue / onHand;
          } else if (unitCost > 0 && totalValue === 0) {
            totalValue = unitCost * onHand;
          } else if (totalValue === 0 && unitCost > 0 && onHand > 0) {
            totalValue = unitCost * onHand;
          }

          const safeId = `${factoryId}-${materialNumber}`.replace(/[^a-zA-Z0-9-_]/g, '');
          idCounts[safeId] = (idCounts[safeId] || 0) + 1;

          let rawImageLink = getVal(['Image', 'Image Link', 'Drive Link', 'Photo', 'Picture']);
          if (rawImageLink && String(rawImageLink).trim().toUpperCase() === '#N/A') {
            rawImageLink = null;
          }

          let processedImageUrl: string | null = null;
          if (rawImageLink) {
            const rawStr = String(rawImageLink);
            const links = rawStr.match(/https:\/\/[^\s,]+/g);
            if (links && links.length > 0) {
              const directLinks = links.map(l => getDirectDriveLink(l) || l);
              processedImageUrl = directLinks.join(' ');
            } else {
              processedImageUrl = getDirectDriveLink(rawStr);
            }
          }

          const part: SparePart = {
            id: safeId,
            factoryId: factoryId,
            materialNumber: String(materialNumber),
            partNumber: String(partNumber),
            description: String(description),
            qtyMoreThan3Years: parseNum(getVal(['More Than 3 Years', 'Qty > 3 Years'])),
            valueMoreThan3Years: parseNum(getVal(['Over 3 Year Value', 'Value > 3 Years'])),
            onHand: onHand,
            unitCost: unitCost,
            totalValue: totalValue,
            spareType: String(getVal(['Spare Type', 'Type', 'S.Type']) || 'General'),
            categoryName: String(getVal(['Sub Category', 'SubCategory', 'Category Name', 'Category', 'Item Category', 'Mat. Group', 'Material Group']) || '-'),
            machine: String(getVal(['Machine Name', 'Machine', 'Equipment Name', 'Equipment', 'Machinery Name', 'Machinery']) || '-'),
            criticality: String(getVal(['Criticality', 'Priority', 'Crit']) || '-'),
          };

          if (processedImageUrl) part.imageUrl = processedImageUrl;

          return part;
        }).filter(item => item !== null) as SparePart[];

        const duplicateCount = Object.values(idCounts).filter(c => c > 1).length;
        const totalCollisions = Object.values(idCounts).reduce((acc, c) => acc + (c > 1 ? c - 1 : 0), 0);

        resolve({
          parts,
          metadata: {
            totalRows: rawRows.length,
            validItems: parts.length,
            filteredItems: filteredCount,
            duplicateIds: duplicateCount,
            totalCollisions: totalCollisions,
            factoryId,
            fileName: file.name
          }
        });
      } catch (error) {
        reject(error);
      }
    };

    reader.onerror = (error) => reject(error);
    reader.readAsArrayBuffer(file);
  });
};