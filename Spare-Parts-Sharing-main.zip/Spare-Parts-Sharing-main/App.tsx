import React, { useState, useMemo, useEffect } from 'react';
import { Upload, Search, LayoutDashboard, SlidersHorizontal, Sparkles, CheckCircle, RefreshCw, Database, FileSpreadsheet, LogOut, ShoppingBag, ShoppingCart, Plus, Trash2, ShieldAlert } from 'lucide-react';
import { parseExcelFile } from './services/excelService';
import { SparePart, User, CartItem } from './types';
import { saveInventory, getInventory, clearDatabase, deleteFactoryData, getOrders, getPendingUsers } from './services/db';
import { DashboardStats } from './components/DashboardStats';
import { InventoryTable } from './components/InventoryTable';
import { AIInsights } from './components/AIInsights';
import { Login } from './components/Login';
import { OrderManagement } from './components/OrderManagement';
import { CartDrawer } from './components/CartDrawer';
import { AddItemModal } from './components/AddItemModal';
import { UserManagement } from './components/UserManagement'; // Import
import { Users } from 'lucide-react';
import { AuditLogs } from './components/AuditLogs';
import { UploadPreviewModal } from './components/UploadPreviewModal';
import { ExcelParseResult } from './services/excelService';

// Factory Configuration
const FACTORIES = [
  {
    id: 'Lanka Tiles',
    name: 'Lanka Tiles',
    theme: { bg: 'bg-blue-50', border: 'border-blue-200', text: 'text-blue-700', icon: 'text-blue-600', hover: 'hover:border-blue-400' }
  },
  {
    id: 'Lanka Wall Tiles',
    name: 'Lanka Wall Tiles',
    theme: { bg: 'bg-emerald-50', border: 'border-emerald-200', text: 'text-emerald-700', icon: 'text-emerald-600', hover: 'hover:border-emerald-400' }
  },
  {
    id: 'Rocell Horana',
    name: 'Rocell Horana',
    theme: { bg: 'bg-amber-50', border: 'border-amber-200', text: 'text-amber-700', icon: 'text-amber-600', hover: 'hover:border-amber-400' }
  },
  {
    id: 'Rocell Eheliyagoda',
    name: 'Rocell Eheliyagoda',
    theme: { bg: 'bg-purple-50', border: 'border-purple-200', text: 'text-purple-700', icon: 'text-purple-600', hover: 'hover:border-purple-400' }
  },
];

function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [parts, setParts] = useState<SparePart[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'dashboard' | 'inventory' | 'orders' | 'users' | 'audit'>('dashboard');
  const [processingFactory, setProcessingFactory] = useState<string | null>(null);
  const [showAI, setShowAI] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showAddItemModal, setShowAddItemModal] = useState(false);
  const [loadingDB, setLoadingDB] = useState(false);
  
  // Upload Preview State
  const [uploadPreview, setUploadPreview] = useState<ExcelParseResult | null>(null);
  const [isConfirmingUpload, setIsConfirmingUpload] = useState(false);

  // Cart State
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  const [notificationCounts, setNotificationCounts] = useState({ orders: 0, users: 0 });

  // Load data from DB on Login
  useEffect(() => {
    if (currentUser) {
      refreshData();
      fetchNotifications();

      // Poll for notifications every 30 seconds
      const interval = setInterval(fetchNotifications, 30000);
      return () => clearInterval(interval);
    }
  }, [currentUser]);

  const refreshData = async () => {
    setLoadingDB(true);
    const data = await getInventory();
    setParts(data);
    setLoadingDB(false);
  };

  const fetchNotifications = async () => {
    if (!currentUser) return;
    try {
      // 1. Orders
      const allOrders = await getOrders(currentUser);
      const pendingOrders = allOrders.filter(o =>
        o.status === 'pending' &&
        (currentUser.role === 'admin' || (o.items.length > 0 && o.items[0].fromFactory === currentUser.factoryAffiliation))
      ).length;

      // 2. Users (Admin Only)
      let pendingUsers = 0;
      if (currentUser.role === 'admin') {
        const users = await getPendingUsers();
        pendingUsers = users.length;
      }

      setNotificationCounts({ orders: pendingOrders, users: pendingUsers });
    } catch (error) {
      console.error("Failed to fetch notifications", error);
    }
  };

  // --- Cart Actions ---
  const handleAddToCart = (part: SparePart) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.id === part.id);
      if (existing) {
        // If already exists, increment qty if stock allows
        if (existing.orderQty < existing.onHand) {
          return prev.map(item => item.id === part.id ? { ...item, orderQty: item.orderQty + 1 } : item);
        }
        return prev;
      }
      return [...prev, { ...part, orderQty: 1 }];
    });
    setIsCartOpen(true);
  };

  const handleUpdateCartQty = (id: string, qty: number) => {
    setCartItems(prev => prev.map(item => item.id === id ? { ...item, orderQty: qty } : item));
  };

  const handleRemoveFromCart = (id: string) => {
    setCartItems(prev => prev.filter(item => item.id !== id));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // Track which factories have data uploaded
  const uploadedFactories = useMemo(() => {
    return new Set(parts.map(p => p.factoryId));
  }, [parts]);

  const handleFactoryUpload = (factoryName: string) => async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setProcessingFactory(factoryName);
      try {
        const file = e.target.files[0];
        const result = await parseExcelFile(file, factoryName);
        setUploadPreview(result);
      } catch (error) {
        console.error("Error parsing or saving file", error);
        alert("Error parsing Excel file. Please check the format.");
        setProcessingFactory(null);
      }
    }
  };

  const confirmUpload = async () => {
    if (!uploadPreview) return;
    
    setIsConfirmingUpload(true);
    try {
      await saveInventory(uploadPreview.parts, currentUser?.username || 'unknown');
      await refreshData();
      
      // Success Cleanup
      setUploadPreview(null);
      setProcessingFactory(null);
      if (showUploadModal) setShowUploadModal(false);
      
      alert(`Successfully uploaded ${uploadPreview.parts.length} items to ${uploadPreview.metadata.factoryId}`);
    } catch (error) {
      console.error("Upload failed", error);
      const errorMsg = (error as any).message || String(error);
      if (errorMsg.toLowerCase().includes('permission')) {
        alert(`Permission Error: The database denied the request. 
        
This usually means the Firestore Security Rules on the server are NOT updated. 

Please ensure you have deployed 'firestore.rules' or manually updated them in the Firebase Console.
(Technical Details: ${errorMsg})`);
      } else {
        alert(`Failed to save items to database. 
        
Ensure the Excel format is correct and you have a stable internet connection.
(Error: ${errorMsg})`);
      }
    } finally {
      setIsConfirmingUpload(false);
    }
  };

  // Filter State
  const [factoryFilter, setFactoryFilter] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('');
  const [criticalityFilter, setCriticalityFilter] = useState<string>('');

  const filteredParts = useMemo(() => {
    let result = parts;

    // Apply Facilitated Filters
    if (factoryFilter) result = result.filter(p => p.factoryId === factoryFilter);
    if (categoryFilter) result = result.filter(p => p.categoryName === categoryFilter);
    if (criticalityFilter) {
      result = result.filter(p => {
        const raw = (p.criticality || '').trim().toLowerCase();
        const rawDesc = (p.description || '').trim().toLowerCase();
        if (criticalityFilter === 'Non Using') return raw.includes('non') || raw.includes('unused') || rawDesc.includes('non using');
        if (criticalityFilter === 'Vital') return raw.includes('vita');
        if (criticalityFilter === 'Essential') return raw.includes('essen');
        if (criticalityFilter === 'Desirable') return raw.includes('desir') || raw.includes('norm');
        return true;
      });
    }

    if (!searchQuery.trim()) return result;
    const terms = searchQuery.toLowerCase().trim().split(/\s+/);

    return result
      .map(part => {
        let score = 0;
        const searchPool = [
          { val: part.materialNumber?.toLowerCase(), weight: 10 },
          { val: part.partNumber?.toLowerCase(), weight: 8 },
          { val: part.description?.toLowerCase(), weight: 5 },
          { val: part.machine?.toLowerCase(), weight: 3 },
          { val: part.categoryName?.toLowerCase(), weight: 2 },
          { val: part.factoryId?.toLowerCase(), weight: 1 },
        ];

        terms.forEach(term => {
          searchPool.forEach(({ val, weight }) => {
            if (!val) return;
            if (val === term) score += weight * 5; // Perfect match
            else if (val.startsWith(term)) score += weight * 3; // Prefix match
            else if (val.includes(term)) score += weight * 1; // Substring match
          });
        });

        return { part, score };
      })
      .filter(item => item.score > 0)
      .sort((a, b) => b.score - a.score)
      .map(item => item.part);
  }, [parts, searchQuery, factoryFilter, categoryFilter, criticalityFilter]);

  const handleExportCSV = () => {
    if (filteredParts.length === 0) return;
    
    const headers = ['Material Number', 'Description', 'Factory', 'Category', 'Criticality', 'On Hand', 'Price', 'Total Value'];
    const rows = filteredParts.map(p => [
      `"${p.materialNumber}"`,
      `"${p.description}"`,
      `"${p.factoryId}"`,
      `"${p.categoryName}"`,
      `"${p.criticality}"`,
      p.onHand,
      p.unitCost,
      p.totalValue
    ]);

    const csvContent = [headers, ...rows].map(e => e.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `spare_parts_export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Auth Guard
  if (!currentUser) {
    return <Login onLogin={setCurrentUser} />;
  }

  const FactoryCard: React.FC<{ factory: typeof FACTORIES[0] }> = ({ factory }) => {
    const isUploaded = uploadedFactories.has(factory.name);
    const isProcessing = processingFactory === factory.name;

    return (
      <div className={`
        relative rounded-xl border-2 transition-all duration-200 overflow-hidden flex flex-col
        ${isUploaded ? 'bg-white border-gray-200' : `${factory.theme.bg} ${factory.theme.border} ${factory.theme.hover}`}
        ${isProcessing ? 'opacity-70 pointer-events-none' : ''}
      `}>
        <div className="p-6 flex flex-col items-center text-center flex-1 gap-4">
          {/* Icon Status */}
          <div className={`w-12 h-12 rounded-full flex items-center justify-center ${isUploaded ? 'bg-green-100' : 'bg-white shadow-sm'}`}>
            {isProcessing ? (
              <RefreshCw className={`w-6 h-6 animate-spin ${factory.theme.text}`} />
            ) : isUploaded ? (
              <CheckCircle className="w-6 h-6 text-green-600" />
            ) : (
              <FileSpreadsheet className={`w-6 h-6 ${factory.theme.icon}`} />
            )}
          </div>

          <h3 className={`font-bold text-lg ${isUploaded ? 'text-gray-900' : factory.theme.text}`}>
            {factory.name}
          </h3>

          {/* Stats if uploaded */}
          {isUploaded ? (
            <p className="text-xs text-gray-500">
              {parts.filter(p => p.factoryId === factory.name).length} items loaded
            </p>
          ) : (
            <p className="text-xs opacity-70">Upload inventory excel file</p>
          )}
        </div>

        {/* Action Button - Only Admin can upload/delete */}
        {currentUser.role === 'admin' && (
          <div className="flex border-t border-gray-100">
            <label className={`
                flex-1 py-3 text-sm font-medium text-center cursor-pointer transition-colors
                ${isUploaded
                ? 'bg-gray-50 text-gray-600 hover:bg-gray-100'
                : 'bg-white/50 hover:bg-white text-gray-700 hover:bg-gray-50'}
            `}>
              {isProcessing ? 'Processing... ' : isUploaded ? 'Replace Data' : 'Upload Data'}
              <input
                type="file"
                accept=".xlsx, .xls"
                onChange={handleFactoryUpload(factory.name)}
                className="hidden"
                disabled={isProcessing}
              />
            </label>
            {isUploaded && (
              <button
                onClick={async () => {
                  if (confirm(`Are you sure you want to delete ALL data for ${factory.name}? This action cannot be undone.`)) {
                    setProcessingFactory(factory.name);
                    try {
                      await deleteFactoryData(factory.name, currentUser.username);
                      await refreshData();
                    } catch (error) {
                      console.error("Error deleting factory data:", error);
                      alert("Failed to delete data. Please try again.");
                    } finally {
                      setProcessingFactory(null);
                    }
                  }
                }}
                className="w-12 flex items-center justify-center border-l border-gray-200 text-gray-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                title="Delete Factory Data"
                disabled={isProcessing}
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Navigation Bar */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-gray-200 sticky top-0 z-30 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-xl flex items-center justify-center text-white font-bold shadow-lg shadow-blue-200 transform transition-transform hover:scale-105">
                <span className="text-xl">S</span>
              </div>
              <div>
                <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-gray-900 to-gray-600 tracking-tight">SpareShare</h1>
                <p className="text-[10px] uppercase tracking-wider text-gray-500 font-bold">
                  {currentUser.role === 'admin' ? 'Admin Portal' : 'User Portal'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-medium text-gray-900">{currentUser.username}</p>
                <p className="text-xs text-gray-500 capitalize">{currentUser.role}</p>
              </div>

              {/* Cart Button (Users only) */}
              {currentUser.role === 'user' && (
                <button
                  onClick={() => setIsCartOpen(true)}
                  className="relative p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                  title="View Cart"
                >
                  <ShoppingCart className="w-5 h-5" />
                  {cartItems.length > 0 && (
                    <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white"></span>
                  )}
                </button>
              )}



              <button
                onClick={() => setCurrentUser(null)}
                className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                title="Logout"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">

        {/* State: No Data or Explicit Upload Mode (Only Admin can see upload modal) */}
        {(parts.length === 0 || showUploadModal) && currentUser.role === 'admin' ? (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Manage Factory Data</h2>
                <p className="text-gray-500 text-sm mt-1">Upload inventory files for each factory separately.</p>
              </div>
              {parts.length > 0 && (
                <button
                  onClick={() => setShowUploadModal(false)}
                  className="text-sm text-blue-600 hover:text-blue-700 font-medium"
                >
                  Return to Dashboard
                </button>
              )}
            </div>

            {/* The 4 Grid Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {FACTORIES.map(factory => (
                <FactoryCard key={factory.id} factory={factory} />
              ))}
            </div>
          </div>
        ) : (
          <>
            {/* Control Bar */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 bg-white/80 backdrop-blur-md p-6 rounded-[2rem] border border-white shadow-[0_8px_30px_rgb(0,0,0,0.04)]">

              {/* Tabs Segmented Control */}
              <div className="flex p-1.5 bg-gray-100/50 rounded-2xl border border-gray-200/50">
                {(['dashboard', 'inventory', 'orders', 'users', 'audit'] as const).map((tab) => {
                  if ((tab === 'users' || tab === 'audit') && currentUser.role !== 'admin') return null;
                  
                  const isActive = activeTab === tab;
                  const icons = {
                    dashboard: LayoutDashboard,
                    inventory: SlidersHorizontal,
                    orders: ShoppingBag,
                    users: Users,
                    audit: ShieldAlert
                  };
                  const Icon = icons[tab];
                  const count = tab === 'orders' ? notificationCounts.orders : (tab === 'users' ? notificationCounts.users : 0);

                  return (
                    <button
                      key={tab}
                      onClick={() => setActiveTab(tab)}
                      className={`
                        relative flex items-center gap-2 px-6 py-2.5 text-xs font-black uppercase tracking-widest rounded-xl transition-all duration-300
                        ${isActive 
                          ? 'bg-white text-blue-600 shadow-sm ring-1 ring-black/5 scale-[1.02]' 
                          : 'text-gray-400 hover:text-gray-600 hover:bg-white/50'}
                      `}
                    >
                      <Icon className={`w-4 h-4 ${isActive ? 'text-blue-600' : 'text-gray-400'}`} />
                      <span className="hidden sm:inline">{tab}</span>
                      {count > 0 && (
                        <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] text-white font-bold border-2 border-white shadow-sm ring-1 ring-red-200">
                          {count > 9 ? '9+' : count}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Search & Actions */}
              <div className="flex flex-col sm:flex-row items-center gap-4 flex-1">
                {activeTab !== 'orders' && (
                  <div className="relative flex-1 w-full max-w-sm group">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 group-focus-within:text-blue-500 transition-colors" />
                    <input
                      type="text"
                      placeholder="Search parts catalog..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-12 pr-4 py-3 bg-gray-50/50 border border-gray-200/60 rounded-2xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500/50 focus:bg-white outline-none text-sm transition-all shadow-inner font-medium"
                    />
                  </div>
                )}

                {/* Admin Quick Actions */}
                {currentUser.role === 'admin' && activeTab !== 'orders' && (
                  <div className="flex items-center gap-3 w-full sm:w-auto">
                    <button
                      onClick={() => setShowAddItemModal(true)}
                      className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-xs font-black uppercase tracking-widest rounded-2xl hover:shadow-xl hover:shadow-blue-200 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-300"
                    >
                      <Plus className="w-4 h-4" />
                      Add Item
                    </button>

                    <button
                      onClick={() => setShowUploadModal(true)}
                      className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-6 py-3 bg-white border border-gray-200 text-gray-700 text-xs font-black uppercase tracking-widest rounded-2xl hover:bg-gray-50 hover:border-gray-300 hover:shadow-md transition-all duration-300"
                    >
                      <Database className="w-4 h-4" />
                      Manage Data
                    </button>

                    <button
                      onClick={async () => {
                        const confirmReset = confirm("WARNING: This will delete ALL inventory and order history. Are you sure?");
                        if (confirmReset) {
                          setLoadingDB(true);
                          try {
                            await clearDatabase(currentUser.username);
                            await refreshData();
                            alert("System reset successful. Inventory and orders have been cleared.");
                          } catch (e) {
                            console.error(e);
                            alert("Failed to clear data. Please check your internet connection.");
                          } finally {
                            setLoadingDB(false);
                          }
                        }
                      }}
                      className="p-3 text-red-500 bg-red-50/50 border border-red-100 rounded-2xl hover:bg-red-50 hover:text-red-600 transition-all hover:shadow-lg hover:shadow-red-200"
                      title="Clear All Data (Core Reset)"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Faceted Filter Bar (Inventory View Only) */}
            {activeTab === 'inventory' && (
              <div className="flex flex-wrap items-center gap-4 bg-white/40 backdrop-blur-sm p-4 rounded-3xl border border-white/60 shadow-sm animate-in fade-in slide-in-from-top-2">
                <div className="flex items-center gap-2 px-3 py-1.5 bg-white/80 rounded-xl border border-gray-200 shadow-tiny overflow-hidden max-w-[200px]">
                  <span className="text-[10px] font-black uppercase text-gray-400 shrink-0">Plant:</span>
                  <select 
                    value={factoryFilter}
                    onChange={(e) => setFactoryFilter(e.target.value)}
                    className="text-xs font-bold text-gray-700 bg-transparent outline-none focus:ring-0 border-none cursor-pointer truncate"
                  >
                    <option value="">All Plants</option>
                    {FACTORIES.map(f => <option key={f.id} value={f.name}>{f.name}</option>)}
                  </select>
                </div>

                <div className="flex items-center gap-2 px-3 py-1.5 bg-white/80 rounded-xl border border-gray-200 shadow-tiny overflow-hidden max-w-[200px]">
                  <span className="text-[10px] font-black uppercase text-gray-400 shrink-0">Class:</span>
                  <select 
                    value={criticalityFilter}
                    onChange={(e) => setCriticalityFilter(e.target.value)}
                    className="text-xs font-bold text-gray-700 bg-transparent outline-none focus:ring-0 border-none cursor-pointer truncate"
                  >
                    <option value="">All Classes</option>
                    <option value="Vital">Vital (V)</option>
                    <option value="Essential">Essential (E)</option>
                    <option value="Desirable">Desirable (D)</option>
                    <option value="Non Using">Non Using</option>
                  </select>
                </div>

                {(factoryFilter || categoryFilter || criticalityFilter) && (
                  <button 
                    onClick={() => { setFactoryFilter(''); setCategoryFilter(''); setCriticalityFilter(''); }}
                    className="text-[10px] font-black uppercase text-red-500 hover:text-red-600 px-3 transition-colors"
                  >
                    Clear Filters
                  </button>
                )}

                <div className="ml-auto flex items-center gap-3">
                  <span className="text-xs font-bold text-gray-400">{filteredParts.length} Results</span>
                  <button 
                    onClick={handleExportCSV}
                    className="flex items-center gap-2 px-4 py-2 bg-emerald-50 text-emerald-600 text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-emerald-100 border border-emerald-100 transition-all"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" />
                    Export CSV
                  </button>
                </div>
              </div>
            )}

            {/* Main Content Area */}
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
              {loadingDB ? (
                <div className="text-center py-20 text-gray-500">Loading Database...</div>
              ) : (
                <>
                  {activeTab === 'dashboard' && (
                    <DashboardStats 
                      parts={filteredParts} 
                      onFilterChange={(type, value) => {
                        if (type === 'factory') setFactoryFilter(value);
                        if (type === 'criticality') setCriticalityFilter(value);
                        setActiveTab('inventory');
                      }}
                    />
                  )}
                  {activeTab === 'inventory' && (
                    <div className="h-[70vh]">
                      <InventoryTable
                        data={filteredParts}
                        currentUser={currentUser}
                        onDataChange={refreshData}
                        cartItems={cartItems}
                        onAddToCart={handleAddToCart}
                      />
                    </div>
                  )}
                  {activeTab === 'orders' && <OrderManagement currentUser={currentUser} />}
                  {activeTab === 'users' && <UserManagement currentUser={currentUser} />}
                  {activeTab === 'audit' && <AuditLogs />}
                </>
              )}
            </div>
          </>
        )
        }
      </main >

      <AIInsights
        data={filteredParts}
        isOpen={showAI}
        onClose={() => setShowAI(false)}
      />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        currentUser={currentUser}
        onUpdateQty={handleUpdateCartQty}
        onRemoveItem={handleRemoveFromCart}
        onClearCart={handleClearCart}
      />

      <AddItemModal
        isOpen={showAddItemModal}
        onClose={() => setShowAddItemModal(false)}
        currentUser={currentUser}
        onSuccess={() => {
          refreshData();
          alert("Item added successfully!");
        }}
      />

      {uploadPreview && (
        <UploadPreviewModal
          isOpen={!!uploadPreview}
          onClose={() => { setUploadPreview(null); setProcessingFactory(null); }}
          onConfirm={confirmUpload}
          result={uploadPreview}
          isUploading={isConfirmingUpload}
        />
      )}
    </div >
  );
}

export default App;